# DC360 — Portable Power BI Source Project

This is a path-sanitized, source-controlled **PBIP/PBIR/TMDL** copy of the fictional `DC360-Operations-Intelligence` report and semantic model supplied with the project. It contains definitions for the five report pages, seven model tables, six relationships and twenty DAX measures. The Sensor Key Mismatches measure uses `+ 0` so an empty unmatched-key set displays zero instead of BLANK.

It is **not** an already refreshed or published Power BI Service report. The original local PBIX and its per-user cached settings were excluded, as were all temporary negative-test files and any original user profile path. The project's source queries contain the neutral example path `C:\DC360-Learning`.

## Open and refresh on Windows

1. Download and extract this archive. From Windows PowerShell in the folder containing it: `tar -xzf DC360-Operations-Intelligence-PBIP-Source.tar.gz`.
2. Download the project CSVs from the GitHub `data/monitoring` directory (ten reading batches) and `data` directory (`sensors.csv`, `assets.csv`, `data-halls.csv`, `alarms.csv`, `incidents.csv`, `work-orders.csv`). Put those in local `monitoring/` and `reference/` folders respectively; don't include duplicate/test CSVs.
3. If your PC permits it, place those two folders under `C:\DC360-Learning`. Otherwise, open the seven model table `.tmdl` query files in the extracted SemanticModel definition and replace `C:\DC360-Learning` with your chosen local folder's escaped M-string path (for example `C:\Users\Public\Documents\DC360-Learning`) before opening the `.pbip`. Do not substitute real tenant URLs or credentials.
4. Open `DC360-Operations-Intelligence.pbip` in a supported Power BI Desktop version. The model cache is intentionally absent, so wait for the first refresh and validate data source settings/permissions. Check that the 50,000 reading rows, 24 sensor keys, 120 alarms, 200 incidents and 500 work orders load from your files.
5. Verify the published learner guide's five pages, source relationships and DAX checks. Save a new **local PBIX** after the report refreshes and all expected cards display correctly. Service publication or workspace sharing requires separate authorization.

The source is original fictional education content, not operational telemetry, licensed data, or tenant information. Do not use for live facility management or as a real-time monitoring system.
